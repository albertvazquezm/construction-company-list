import { ConstructionCompaniesListScreen } from "./screens/ConstructionCompaniesListScreen";

function App() {
  return (
    <ConstructionCompaniesListScreen></ConstructionCompaniesListScreen>
  );
}

export default App;
