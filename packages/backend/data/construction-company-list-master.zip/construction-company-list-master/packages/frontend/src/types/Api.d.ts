export interface ApiCompany {
    id: string;
    name: string;
    specialties: string[];
    logo: string;
    city: string;
}
export type ApiSpecialty = string;